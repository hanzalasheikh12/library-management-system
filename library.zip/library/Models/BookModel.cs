﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Net;


namespace library.Models
{
    public class BookModel
    {
        public static int Bookid;
        string constring = "Data Source=DESKTOP-910HAIT\\SQLEXPRESS;Initial Catalog=project lms;Integrated Security=True";

        public int InsertBookRecord(string bookname, int isbn, int totalcopies, int availablecopies, int maxissueday, int LOCATIONID)
        {
            using (SqlConnection con = new SqlConnection(constring))
            {
                string available = "true";
                con.Open();
                string query = "insert into Book(bookname,isbn,totalcopies,availablecopies,MAXISSUEDAY ,locationid)values(@bookname,@isbn,@totalcopies,@availablecopies,@MAXISSUEDAY ,@LOCATIONID)";
                //           string query = "insert into Book(authorid,authorname,publisher,category,price,quantity,noofavailablebooks,availability)values(@authorid,@author,@publisher,@category,@price,@quantity,@quantity,@available)";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@bookname", bookname);
                cmd.Parameters.AddWithValue("@isbn", isbn);
                cmd.Parameters.AddWithValue("@totalcopies", totalcopies);
                cmd.Parameters.AddWithValue("@availablecopies", availablecopies);
                cmd.Parameters.AddWithValue("@MAXISSUEDAY ", maxissueday);
                cmd.Parameters.AddWithValue("@LOCATIONID", LOCATIONID);
                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {
                    string query1 = "Select max(bookid) from Book";
                    SqlCommand cmd1 = new SqlCommand(query1, con);
                    SqlDataAdapter adp1 = new SqlDataAdapter(cmd1);
                    DataSet ds = new DataSet();
                    adp1.Fill(ds);
                    int a1 = int.Parse(ds.Tables[0].Rows[0][0].ToString());
                    return a1;
                }
                else
                    return 0;
            }
        }
        public DataTable GetBookbyId(int bid)
        {
            Bookid = bid;
            string available = "true";
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(constring))
            {
                con.Open();
                string query = "Select * from Books where bookid=@bid AND availability=@available";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@bid", Bookid);
                cmd.Parameters.AddWithValue("@available", available);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(dt);
            }
            return dt;
        }
        public int EditBookRecord(string bname, string author, string publisher, string category, int price, int quantity)
        {
            using (SqlConnection con = new SqlConnection(constring))
            {
                con.Open();
                string query = "UPDATE Books SET bookname=@bname,authorname=@author,publisher=@publisher,category=@category,price=@price,quantity=@quantity where bookid=@bid";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@bname", bname);
                cmd.Parameters.AddWithValue("@author", author);
                cmd.Parameters.AddWithValue("@publisher", publisher);
                cmd.Parameters.AddWithValue("@category", category);
                cmd.Parameters.AddWithValue("@price", price);
                cmd.Parameters.AddWithValue("@quantity", quantity);
                cmd.Parameters.AddWithValue("@bid", Bookid);
                return cmd.ExecuteNonQuery();
            }
        }
        public int DeleteBookRecord(int id)
        {
            string available = "false";
            int bid = id;
            using (SqlConnection con = new SqlConnection(constring))
            {
                con.Open();
                string query = "Update Books SET availability=@available where bookid=@bid";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@bid", bid);
                cmd.Parameters.AddWithValue("@available", available);
                return cmd.ExecuteNonQuery();
            }
        }
        public DataTable GetAllCategories()
        {
            string available = "true";
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(constring))
            {
                con.Open();
                string query = "Select * from Books where availability=@available";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@available", available);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(dt);
            }
            return dt;
        }
        public DataTable GetAllBooks()
        {
            string available = "true";
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(constring))
            {
                con.Open();
                string query = "Select * from Book where AVAILABLECOPIES=1";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@available", available);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(dt);
            }
            return dt;
        }
        public DataTable GetBookbyCategory(string BOOKNAME)
        {
            string available = "true";
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(constring))
            {
                con.Open();
                //string query = "Select * from Book where availability=@available AND category=@BookNmae";
                string query = "Select * from Book where  BOOKNAME =@BOOKNAME ";
                SqlCommand cmd = new SqlCommand(query, con);
                //cmd.Parameters.AddWithValue("@available", available);
                cmd.Parameters.AddWithValue("@BOOKNAME ", BOOKNAME);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(dt);
            }
            return dt;
        }
        public int BookLocation( int AISLE_NUMBER, int SHELF_NUMBER, string SECTION)
        {
            using (SqlConnection con = new SqlConnection(constring))
            {
                string available = "true";
                con.Open();
                string query = "insert into Location(AISLE_NUMBER,SHELF_NUMBER,SECTION)values(@AISLE_NUMBER,@SHELF_NUMBER,@SECTION)";
                //           string query = "insert into Book(authorid,authorname,publisher,category,price,quantity,noofavailablebooks,availability)values(@authorid,@author,@publisher,@category,@price,@quantity,@quantity,@available)";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.Parameters.AddWithValue("@AISLE_NUMBER", AISLE_NUMBER);
                cmd.Parameters.AddWithValue("@SHELF_NUMBER", SHELF_NUMBER);

                cmd.Parameters.AddWithValue("@SECTION", SECTION);

                int a = cmd.ExecuteNonQuery();
                if (a > 0)
                {
                    string query1 = "Select max(LOCATIONID) from Location";
                    SqlCommand cmd1 = new SqlCommand(query1, con);
                    SqlDataAdapter adp1 = new SqlDataAdapter(cmd1);
                    DataSet ds = new DataSet();
                    adp1.Fill(ds);
                    int a1 = int.Parse(ds.Tables[0].Rows[0][0].ToString());
                    return a1;
                }
                else
                    return 0;
            }

        }
    }
}