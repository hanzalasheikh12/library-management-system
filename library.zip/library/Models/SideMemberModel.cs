﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace library.Models
{
    public class SideMemberModel
    {
        public static int MMemberid;
        string constring = "Data Source=DESKTOP-910HAIT\\SQLEXPRESS;Initial Catalog=project lms ;Integrated Security=True";
        public DataTable GetMyIssuedBooks()
        {
            string status = "issued";
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(constring))
            {
                con.Open();
                //string query = "Select * from Librarian inner Join IssueBook On Member.memberid=IssueBook.memberid inner Join Books On IssueBook.bookid=Books.bookid where IssueBook.state=@state AND Member.memberid=@mid";
                string query = "Select * from Librarian as l inner Join BOOKISSUERETURN as bir On l.LIBRARIANID=bir.LIBRARIANID  inner Join BOOKCOPY as bc On bc.BOOKCOPYID =   bir.BOOKCOPYID inner Join Book b On b.BOOKID=bc.BOOKID where bir.status=@status AND l.LIBRARIANID=@mid";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@status", status);
                cmd.Parameters.AddWithValue("@mid", MMemberid);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(dt);
            }
            return dt;
        }
        public DataTable GetIBooklist()
        {
            string status = "issued";
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(constring))
            {
                con.Open();
                string query = "Select * from BOOKISSUERETURN where status=@status AND memberid=@mid";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@status", status);
                cmd.Parameters.AddWithValue("@mid", MMemberid);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(dt);
            }
            return dt;
        }
        public DataTable GetMyReturnedbooks()
        {
            string status = "returned";
            DataTable dt = new DataTable();
            using (SqlConnection con = new SqlConnection(constring))
            {
                con.Open();
                //string query = "Select * from Member inner Join ReturnBook On Member.memberid=ReturnBook.memberid inner Join IssueBook On ReturnBook.issuebookid=IssueBook.issuebookid inner Join Books On ReturnBook.bookid=Books.bookid where IssueBook.state=@state AND Member.memberid=@mid";
                string query = "Select * from Librarian as l inner Join BOOKISSUERETURN as bir On l.LIBRARIANID=bir.LIBRARIANID  inner Join BOOKCOPY as bc On bc.BOOKCOPYID =   bir.BOOKCOPYID inner Join Book b On b.BOOKID=bc.BOOKID where bir.status=@status AND l.LIBRARIANID=@mid";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@status", status);
                cmd.Parameters.AddWithValue("@mid", MMemberid);
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                adp.Fill(dt);
            }
            return dt;
        }
        public void Mid(int id)
        {
            MMemberid = id;
        }

    }
}
