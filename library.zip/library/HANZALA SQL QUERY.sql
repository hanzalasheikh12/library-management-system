


create table Librarian(
LIBRARIANID int primary key identity(1,1) not null,
LIBRARIANNAME varchar(255),
EMAIL varchar(255),
ADDRESS  varchar(255),
CONTACT varchar(255),
PASSWORD varchar(255),
USERNAME varchar(255),
DATE date
);


create table MEMBERTYPE(
MEMBERTYPEID int PRIMARY key identity(1,1) not null,

MAXBOOKALLOWED int,
DURATIONLIMIT int 
);


create table MEMBER(
MEMBERID int PRIMARY key identity(1,1) not null,
MEMBERNAME varchar(255),
ADDRESS varchar(255),
EMAIL varchar(255),
CONTACT varchar(255),
MEMBERTYPEID  int foreign key References MEMBERTYPE(MEMBERTYPEID)

);

create table LOCATION(
LOCATIONID int  primary key identity(1,1) not null,
AISLE_NUMBER  int,
SHELF_NUMBER  int,
SECTION   varchar(255)
);

create table BOOK(
BOOKID int primary key  identity(1,1) not null,
BOOKNAME varchar(255),
ISBN int,
TOTALCOPIES int,
AVAILABLECOPIES int,
MAXISSUEDAY int,
LOCATIONID  int foreign key References LOCATION(LOCATIONID)
);




create table FINEPOLICY(
FINEPOLICYID int primary key identity(1,1) not null,
FINEAMMOUNT int ,
MAINDUEDAY int,
MEMBERTYPEID  int foreign key References MEMBERTYPE(MEMBERTYPEID)
);



create table AUTHOR(
AUTHOR_ID int primary key identity(1,1) not null,
AUTHORNAME varchar(255)
);
create table BOOKAUTHOR(
BOOKAUTHORID int primary key identity(1,1) not null,
BOOKID  int foreign key References BOOK(BOOKID),
AUTHOR_ID int foreign key References AUTHOR(AUTHOR_ID)
);


create table BOOKCOPY(
BOOKCOPYID int primary key identity(1,1) not null,
BOOKID  int foreign key References BOOK(BOOKID),
NOAVAILABLE int
);

create table BOOKISSUERETURN(
ISSUEID int primary key identity(1,1) not null,
LIBRARIANID int foreign key References LIBRARy(LIBRARIANID),
BOOKCOPYID int foreign key References BOOKCOPY(BOOKCOPYID),
MEMBERID int foreign key References MEMBER(MEMBERID),
ISSUE_DATE  date,
DUE_DATE   date,
RETURN_DATE  date,
FINEPOLICYID int foreign key References FINEPOLICY(FINEPOLICYID),
PAYDATE date, 
STATUS varchar(255)
);

