﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using library.Models;
using System.Reflection;

namespace library.Controllers
{
    public class MemberController : Controller
    {
        [HttpGet]
        public IActionResult AddMember()
        {
            return View();
        }
        [HttpPost]
        public IActionResult InsertMember(IFormCollection fm)
        {
            MemberModel mod = new MemberModel();
            string MEMBERNAME = fm["txtMEMBERNAME"];
            string ADDRESS = fm["txtADDRESS"];
            string EMAIL = fm["txtEMAIL"];
            string CONTACT = fm["txtCONTACT"];
            int MEMBERTYPEID = Convert.ToInt32(fm["txtMEMBERTYPEID"]);
            int a = mod.InsertMemberRecord(MEMBERNAME, ADDRESS, EMAIL, CONTACT, MEMBERTYPEID);
            if(a > 0)
            {
                
                ViewBag.Heading = "SUCCESS";
                ViewBag.Message = "Member Adeded, Note Username of Member is Member id which is: "+a;
                return View("~/Views/Shared/Message.cshtml");
            }
            return View("~/Views/Shared/Error.cshtml");
        }
        [HttpGet]
        public IActionResult UpdateMember()
        {
            return View();
        }
        public IActionResult DeleteMember()
        {
            return View();
        }
        public IActionResult ViewMemberdetails()
        {
            MemberModel model = new MemberModel();
            DataTable dt = model.GetAllMembers();
            return View("ViewMemberdetails",dt);
        }
        [HttpPost]
        public IActionResult SearchMember(int txtmid)
        {
            ViewBag.flag = 1;
            MemberModel mod = new MemberModel();
            int memid = txtmid;
            DataTable dt = mod.GetMemberbyId(memid);
            return View("UpdateMember",dt);
        }
        [HttpGet]
        [HttpPost]
        public IActionResult EditMember(IFormCollection fm)
        {
           
            MemberModel model1 = new MemberModel();
            //string MEMBERNAME = fm["txtmid"];
            string MEMBERNAME = fm["txtMEMBERNAME"];
            string ADDRESS = fm["txtADDRESS"];
            string EMAIL = fm["txtEMAIL"];
            string CONTACT = fm["txtCONTACT"];
            int MEMBERTYPEID = Convert.ToInt32(fm["txtMEMBERTYPEID"]);
            int b = model1.EditMemberRecord(MEMBERNAME, EMAIL, CONTACT, ADDRESS, MEMBERTYPEID);
            if (b > 0)
            {
                ViewBag.Heading = "SUCCESS";
                ViewBag.Message = "Member updated";
                return View("~/Views/Shared/Message.cshtml");
            }
            return View("~/Views/Shared/Error.cshtml");
        }
        public IActionResult RemoveMember(IFormCollection frm)
        {
            
            MemberModel model = new MemberModel();
            int memid = Convert.ToInt32(frm["txtmid"]);
            int a = model.DeleteMemberRecord(memid);
            if (a > 0)
            {
                ViewBag.Heading = "SUCCESS";
                ViewBag.Message = "Member deleted";
                return View("~/Views/Shared/Message.cshtml");
            }
            return View("~/Views/Shared/Error.cshtml");
        }
        [HttpGet]
        public IActionResult UpdateLibrarian()
        {
            MemberModel model = new MemberModel();
            DataTable dt = model.SearchLibraian();
            return View("UpdateLibrarian", dt);
        }
        public IActionResult UpdateLibrarianInfo(IFormCollection frm)
        {

            MemberModel model1 = new MemberModel();
            string libname = frm["txtlibname"];
            string email = frm["txtemail"];
            string contact = frm["txtcontact"];
            string address = frm["txtaddress"];
            string uname = frm["txtusername"];
            string password = frm["txtpassword"];
            int b = model1.UpdateLibrarianRecord(libname, email, contact, address, uname, password);
            if (b > 0)
            {
                ViewBag.Heading = "SUCCESS";
                ViewBag.Message = "Librarian updated";
                return View("~/Views/Shared/Message.cshtml");
            }
            return View("~/Views/Shared/Error.cshtml");
        }
        public IActionResult ViewLibrariandetails()
        {
            MemberModel model = new MemberModel();
            DataTable dt = model.GetLibrarian();
            return View("ViewLibrariandetails", dt);
        }
    }
}
