﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;
using library.Models;
using static System.Collections.Specialized.BitVector32;

namespace library.Controllers
{
    public class BookController : Controller
    {
        [HttpGet]
        public IActionResult AddBook()
        {
            return View();
        }
        [HttpPost]
        public IActionResult InsertBook(IFormCollection fm)
        {
            BookModel mod = new BookModel();
            string bookname = fm["txtbookname"].ToString();
            int isbn = Convert.ToInt32(fm["txtisbn"]);
            int totalcopies = Convert.ToInt32(fm["txttotalcopies"]);
            int availablecopies = Convert.ToInt32(fm["txtavailablecopies"]);
            int maxissueday = Convert.ToInt32(fm["txtmaxissueday"]);
            int locationid = Convert.ToInt32(fm["txtlocationid"]);
            int a = mod.InsertBookRecord(bookname, isbn, totalcopies, availablecopies, maxissueday, locationid);
            if (a > 0)
            {
                ViewBag.dashboard = "lib";
                ViewBag.Heading = "SUCCESS";
                ViewBag.Message = "Book Adeded, Note Book id of this Book is: " +a;
                return View("~/Views/Shared/Message.cshtml");
            }
            return View("~/Views/Shared/Error.cshtml");
        }
        [HttpGet]
        public IActionResult UpdateBook()
        {
            return View();
        }
        [HttpGet]
        public IActionResult DeleteBook()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SearchBook(int txtbid)
        {
            ViewBag.flag = 1;
            BookModel mod = new BookModel();
            int bid = txtbid;
            DataTable dt = mod.GetBookbyId(bid);
            return View("UpdateBook", dt);
        }
        [HttpGet]
        [HttpPost]
        public IActionResult EditBook(IFormCollection fm)
        {
            BookModel mod = new BookModel();
            string bname = fm["txtbname"];
            string author = fm["txtauthorname"];
            string publisher = fm["txtpublisher"];
            string category = fm["txtcategory"];
            int price = Convert.ToInt32(fm["txtprice"]);
            int quantity = Convert.ToInt32(fm["txtquantity"]);
            int a = mod.EditBookRecord(bname, author, publisher, category, price, quantity);
            if (a > 0)
            {
                ViewBag.dashboard = "lib";
                ViewBag.Heading = "SUCCESS";
                ViewBag.Message = "Book updated";
                return View("~/Views/Shared/Message.cshtml");
            }
            return View("~/Views/Shared/Error.cshtml");
        }
        public IActionResult RemoveBook(IFormCollection frm)
        {

            BookModel model = new BookModel();
            int bid = Convert.ToInt32(frm["txtbid"]);
            int a = model.DeleteBookRecord(bid);
            if (a > 0)
            {
                ViewBag.dashboard = "lib";
                ViewBag.Heading = "SUCCESS";
                ViewBag.Message = "Book deleted";
                return View("~/Views/Shared/Message.cshtml");
            }
            return View("~/Views/Shared/Error.cshtml");
        }
        public IActionResult ViewBooks()
        {
            
            if(HomeController.user=="mem")
            {
                ViewBag.user = "mem";
            }
            BookModel model = new BookModel();
            DataTable dt = model.GetAllBooks();
            return View("ViewBooks", dt);
        }
        public IActionResult Searchviewbook(IFormCollection fm)
        {
            if (HomeController.user == "mem")
            {
                ViewBag.user = "mem";
            }
            BookModel model = new BookModel();
            
            string category = fm["txtcategory"];
            if (category != "All")
            {
                DataTable dt = model.GetBookbyCategory(category);
                return View("ViewBooks", dt);
            }
            else
            {
                DataTable dt = model.GetAllBooks();
                return View("ViewBooks", dt);
            }

        }
        public IActionResult Location()
        {



            return View();
        }
        [HttpPost]
        public IActionResult Location(IFormCollection fm)
        {
            BookModel mod = new BookModel();
            string SECTION = fm["txtSECTION"].ToString();
            int AISLE_NUMBER = Convert.ToInt32(fm["txtAISLE_NUMBER"]);
            int SHELF_NUMBER = Convert.ToInt32(fm["txtSHELF_NUMBER"]);
           
            int a = mod.BookLocation(AISLE_NUMBER, SHELF_NUMBER, SECTION);
            if (a > 0)
            {
                ViewBag.dashboard = "lib";
                ViewBag.Heading = "SUCCESS";
                ViewBag.Message = "Book Adeded, Note Book id of this Book is: " + a;
                return View("~/Views/Shared/Message.cshtml");
            }
            return View("~/Views/Shared/Error.cshtml");



        }
     }


    
}
